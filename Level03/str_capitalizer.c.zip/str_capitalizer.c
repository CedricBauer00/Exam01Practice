#include <unistd.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
	int i;
	int j;
	char c;

	j = 1;
	i = 0;
	if (argc > 1)
	{
		while (j < argc)
		{
			i = 0;
			while (argv[j][i] != '\0')
			{
				while (argv[j][i] == ' ' || argv[j][i] == '\t')
				{
					write(1, &argv[j][i] ,1);
					i++;
				}
				while (argv[j][i] != '\0' && argv[j][i] != ' ' && argv[1][i] != '\t')
				{
					if (i == 0 && argv[1][i] >= 'a' && argv[1][i] <= 'z')
						c = argv[j][i] - 32;
					else if ((argv[j][i - 1] == ' ' || argv[j][i - 1] == '\t') && argv[1][i] >= 'a' && argv[1][i] <= 'z')
						c = argv[j][i] - 32;
					else if ((argv[j][i - 1] != ' ' && argv[j][i - 1] != '\t') && argv[j][i] >= 'A' && argv[j][i] <= 'Z')
						c = argv[j][i] + 32;
					else
						c = argv[j][i];
					write(1, &c, 1);
					i++;
				}
			}
			write(1, "\n", 1);
			j++;
		}
	}
	if (argc == 1)
		write(1, "\n", 1);
}